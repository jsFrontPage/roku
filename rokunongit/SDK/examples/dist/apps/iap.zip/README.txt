The rcsiap application shows how to 
use roChannelStore. It shows a poster screen 
with a filter banner of product types. When a 
new category is selected, the app receives 
events to refresh the content for the category.  
It's a minimalist application, designed just to 
show how to query the channel store and enter 
the purchase flow.
