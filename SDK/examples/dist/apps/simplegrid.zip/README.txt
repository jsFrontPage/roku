The simplegrid application shows how to
use roGridScreen. It shows a grid screen
with several categories. It's a minimalist
application, designed to just show how to
set up this screen type.
